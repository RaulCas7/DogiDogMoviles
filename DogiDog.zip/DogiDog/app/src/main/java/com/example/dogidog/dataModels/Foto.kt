package com.example.dogidog.dataModels

import android.net.Uri

data class Foto(
    val imageUri: Uri,
    val fecha: Long
)

