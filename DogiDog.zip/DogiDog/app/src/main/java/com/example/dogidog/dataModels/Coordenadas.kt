package com.example.dogidog.dataModels

data class Coordenadas(
    val latitud: Double,
    val longitud: Double
)
